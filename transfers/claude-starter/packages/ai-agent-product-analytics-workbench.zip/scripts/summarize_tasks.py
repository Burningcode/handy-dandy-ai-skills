"""Summarize an explicit local synthetic task CSV; no credentials or remote access."""
import argparse, csv, json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("csv_path", type=Path)
a = p.parse_args()
with a.csv_path.open(newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    required = {"task_id","acknowledged","claimed","state_confirmed","durable"}
    if not required.issubset(reader.fieldnames or []):
        raise ValueError("Missing required task CSV fields")
    rows = list(reader)
if not rows:
    raise ValueError("Empty task population")
if any(not r["task_id"].strip() for r in rows) or len({r["task_id"] for r in rows}) != len(rows):
    raise ValueError("Task IDs must be distinct")
for row in rows:
    if any(row[k] not in {"0", "1"} for k in ["acknowledged","claimed","state_confirmed","durable"]):
        raise ValueError("State fields must be 0 or 1")
total = len(rows)
counts = {k: sum(int(r[k]) for r in rows) for k in ["acknowledged","claimed","state_confirmed","durable"]}
verified_claims = sum(int(r["claimed"]) == 1 and int(r["state_confirmed"]) == 1 for r in rows)
false_claims = [r["task_id"] for r in rows if r["claimed"] == "1" and r["state_confirmed"] == "0"]
state_review = [r["task_id"] for r in rows if (r["durable"] == "1" and r["state_confirmed"] == "0") or (r["state_confirmed"] == "1" and r["acknowledged"] == "0")]
print(json.dumps({"eligible_tasks": total, "counts": counts, "population_rates": {k: counts[k]/total for k in ["acknowledged","state_confirmed","durable"]}, "claim_verification": {"numerator": verified_claims, "denominator": counts["claimed"], "rate": verified_claims/counts["claimed"] if counts["claimed"] else None}, "false_completion_task_ids": false_claims, "state_order_review_ids": state_review, "state_order_note": "Review ordering and definitions for flagged IDs; a failed acknowledgement can still accompany a successful state change."}, indent=2))
