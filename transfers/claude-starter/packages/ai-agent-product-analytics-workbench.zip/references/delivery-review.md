# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Use eligible tasks as the denominator for population outcomes and completion claims for claim-verification metrics.
- Keep acknowledgement, state confirmation, and durable value separate.
- Identify false completion claims even when technical success is high.
- Give verification and privacy requirements for each event/state join; do not claim production prevalence from a synthetic cohort.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
