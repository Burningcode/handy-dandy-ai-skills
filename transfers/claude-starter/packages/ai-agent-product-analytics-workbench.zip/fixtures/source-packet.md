# DeskPilot: acknowledged work versus verified outcomes

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Source packet
Read `fixtures/agent-tasks.csv`. The complete synthetic observation population is 12 eligible support-record tasks from a seven-day cohort with a completed seven-day durability observation window. IDs are synthetic and pseudonymous. Acknowledged means a tool returned a technical success signal. Claimed means the agent told the user the task was complete. State-confirmed means an independent read found the correct requested support record. Durable means a delayed read still found the intended usable record without a reversal. The data contains no user conversations or real account details.

An acknowledgement is not a completion proof. State confirmation without durability is not necessarily a failure: one record was intentionally reversed and one lost its intended usable state. The data describes this cohort only; it cannot establish production quality across customers or versions. Support-record creation is the bounded job, not purchases or account-permission changes.

## Buyer request
Audit the completion story, calculate separate acknowledgement, claim-verification, state-confirmed, and durable-outcome rates with explicit denominators, and write a minimum instrumentation/verification plan. Preserve attempted, acknowledged, verified, and durable states. Name the most serious silent failure and a supervision decision. Proposed quality thresholds must be labeled, and no aggregate may average away a false completion claim.
