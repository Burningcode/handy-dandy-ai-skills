# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Normalize seat count and feature-qualified plan price, not advertised entry prices alone.
- Separate observed behavior, documented capability, vendor claim, customer report, and unknown.
- Propose a response tied to dispatcher behavior and an explicit non-opportunity.
- Keep the same job, population, capture date, and access limitation across alternatives.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
