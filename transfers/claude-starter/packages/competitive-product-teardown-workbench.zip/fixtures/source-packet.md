# TaskHarbor: dispatch software comparison

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Comparison contract
Capture date for this synthetic packet: 2026-09-30. Job: a 20-person field-service business assigns the next day's work, handles a worker cancellation, and exports the revised schedule. Compare the same team size and USD monthly billing; do not infer annual discounts, taxes, service fees, or universal behavior.

## Synthetic source register
S1: ClearQueue Basic pricing snapshot: $12 per active seat per month, minimum five seats. Cancellation reassignment is documented as a manual drag action. CSV export is documented. No observed user session is supplied.
S2: RouteBoard Team pricing snapshot: $220 per workspace per month, includes 25 active seats. Vendor claims automatic reassignment, but the claim has not been tested. CSV export is documented only on the $350 Business plan.
S3: TaskHarbor observed authorized session on its current plan: cancellation exposes a visible unassigned-job queue and one-click reassignment; the dispatcher must choose a replacement. Export succeeded for the sample revised schedule. Current paid price is $260 per workspace per month for up to 25 seats.
S4: Three synthetic dispatcher interviews preferred visibility into uncovered jobs over hidden automatic changes. This is directional customer-reported evidence, not proven market preference.

## Buyer request
Produce a competitive teardown for TaskHarbor. Normalize the 20-seat comparison, label observed versus vendor-claimed versus reported evidence, identify a defensible response and a non-opportunity, and propose the cheapest useful validation. Preserve unknown functionality and pricing instead of claiming a missing feature from silence.
