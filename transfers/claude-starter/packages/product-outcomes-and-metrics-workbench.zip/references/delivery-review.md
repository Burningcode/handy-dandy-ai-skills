# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Distinguish conditional repeat rate from whole-population repeated value.
- Define mature windows and authoritative completed-work state.
- Select a focused causal chain; do not replace one output list with a long scorecard.
- Label all new targets proposed; keep support, error, and manual-route guardrails meaningful.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
