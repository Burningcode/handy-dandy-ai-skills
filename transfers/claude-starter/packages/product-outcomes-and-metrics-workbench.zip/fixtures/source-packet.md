# CompassFlow: onboarding outcome design

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Source packet
In a mature synthetic cohort of 500 newly eligible accounts, 200 completed a first verified workflow within 14 days of eligibility; 120 of those 200 repeated a verified workflow during days 15-28. The whole cohort has a complete 28-day observation window. A verified workflow means the authoritative workspace contains the requested record with required fields, not an assistant completion message.

The team proposes shipping three onboarding screens, adding an AI assistant, and building an adoption dashboard as its OKR. The decision is what behavior to prioritize over the next quarter. Support costs, retention impact, and intervention effects are unknown. Four of 10 research sessions contained uncertainty about required setup fields. The product has a manual setup route that remains available.

## Buyer request
Replace the output-based OKR with one outcome objective and a focused metric set. Distinguish first-workflow completion, repeat rate among completers, and repeat outcome across all eligible accounts. Write numerator, denominator, eligibility, window, authoritative source, segment, and guardrail contracts. Label targets and experiment thresholds as proposed and state the decision they trigger.
