# PaperRelay: export build-versus-partner decision

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Evidence packet
PaperRelay is a B2B operations workspace. Forty of 200 accounts requested a shareable signed-PDF export in the last quarter. This is demand incidence, not proof of willingness to pay or churn reduction. The existing CSV export and document template engine are verified capabilities. Signature verification requirements and external-recipient data permissions remain unresolved.

Option A, internal build: six weeks, $30,000 initial engineering cost, then $1,000 monthly maintenance. Full demanded scope is estimated, not guaranteed.
Option B, partner: two weeks, $8,000 integration cost, then $1,200 monthly vendor cost. A sandbox prototype met the basic export format, but data-retention and signature controls remain unapproved.
Option C, improve current export: three weeks, $15,000 initial cost, $300 monthly maintenance. Eight of the 40 requesting accounts said better layout alone would meet their need. The sample does not establish adoption or commercial results.

Available initial budget is $35,000. Costs exclude revenue gains, taxes, opportunity cost, and future vendor price changes. The decision horizon is 12 months. Product leadership owns the decision, but no named person or final deadline is supplied.

## Buyer request
Create an executive decision brief comparing all three options on a common 12-month cost basis. Challenge one foundational assumption. Recommend a conditional staged choice, show what unresolved constraints can veto it, and specify the next decision and evidence needed. Do not infer revenue or churn savings.
