# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Use the same 12-month cost unit for every option and retain unresolved legal/security constraints as vetoes.
- Treat request incidence as demand evidence, not revenue or churn savings.
- Give the strongest rejected option a credible reason to win under changed evidence.
- State an accountable decision role, conditional next gate, and what evidence is still required.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
