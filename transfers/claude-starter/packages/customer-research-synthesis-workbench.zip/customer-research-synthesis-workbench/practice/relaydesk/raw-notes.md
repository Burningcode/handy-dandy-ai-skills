# RelayDesk research packet

All names, companies, dates, statements and counts are original fictional simulation material. No actual research participant or customer record is included. Source IDs and paragraph labels below are stable locators. Only quoted spans marked verbatim are transcript excerpts; all other notes are paraphrases or researcher observations.

## Collection context — C0

C0.1 RelayDesk is a fictional coordination tool for equipment-service teams. The product lead must choose the next two-week discovery focus: automatic reminder escalation or clearer handoff ownership. No implementation budget is approved. Named owner and decision date are not supplied.

C0.2 A customer-success manager recruited four existing account leads who had replied to a recent check-in. Two are from small teams and two from multi-site teams. No nonresponders, churned accounts, field technicians or new prospects were interviewed. Interviews occurred October 1–4, 2026. Notes omit call duration and full question wording except where shown. All packet data may be used for this fictional exercise.

## I1 — P1, account Aster, small team, operations lead, October 1

I1.1 Interviewer asked, “What happens after you hand a job to the next person?” P1 described posting a job in team chat and checking for a reply. Researcher paraphrase: on busy days they sometimes do not know whether the assigned person has seen it.

I1.2 Verbatim P1: “I do not need another ping. I need to know who has picked it up.” No screen or log was observed.

I1.3 Researcher paraphrase: P1 would still phone the technician for an urgent repair. P1 did not discuss willingness to pay or notification frequency.

## I2 — P2, account Birch, small team, owner, October 2

I2.1 Interviewer asked, “Would an automatic reminder stop work slipping through the cracks?” Verbatim P2: “Probably, yes, a reminder sounds helpful.” Researcher note: answer followed a feature suggestion; no recent failed handoff was elicited.

I2.2 Asked to describe yesterday, P2 reported one shared inbox checked twice daily. Researcher paraphrase: their two technicians already confirm assignments by phone. P2 said they were satisfied with this arrangement. Ownership visibility was not directly asked.

I2.3 Verbatim P2: “Please do not message everyone every time. I am usually the one who needs the reminder.” No product interaction was observed.

## I3 — P3, account Cedar, multi-site team, regional coordinator, October 3

I3.1 Interviewer asked for a recent delayed job. P3 reported that Site East assumed Site West had accepted a transfer, while West thought East still owned it. The researcher did not inspect the job record.

I3.2 Verbatim P3: “We had reminders, but nobody knew whose turn it was.” P3 requested a named owner and acceptance status. P3 also asked for a daily unresolved-job digest, not an alert for each update.

I3.3 Researcher note: P3 mentioned two delays in the previous month but could recall details of only the transfer above. No complete monthly job count, delay definition or baseline was supplied.

## I4 — P4, account Drift, multi-site team, dispatcher, October 4

I4.1 Researcher observed a scripted demonstration on a test job. P4 opened an assignment board, identified a named technician and showed an acceptance timestamp. The demonstration was requested in the interview, not an observation of ordinary live work.

I4.2 Verbatim P4: “Ownership is already clear for us. The customer moves the appointment, and then we wait.” P4 described requiring customer access confirmation before travel.

I4.3 P4 asked for reminders to the dispatcher after an appointment change; they did not request automatic customer messages. Researcher paraphrase: an urgent push notification could interrupt an active call. Historical frequency was not asked.

## Support export — S0

S0.1 Export window September 20–October 5, 2026. These are five selected support records tagged handoff or reminders by a support analyst. It is not a complete account or ticket sample. Segment metadata comes from the account register used above; account Elm has no register entry. Ticket text is support-agent paraphrase, not a verbatim customer quote.

S1 Ticket 801, Aster, P1: asked where to see who accepted the task. Analyst tagged reminders. No resolution recorded.

S2 Ticket 802, Aster, P1: duplicate follow-up on ticket 801; same request. Analyst tagged handoff.

S3 Ticket 803, Cedar, P3: requested an accepted-by field after a cross-site transfer. Agent wrote “customer says nobody receives reminders,” without recording notification settings or inspecting delivery logs.

S4 Ticket 804, Drift, P4: requested a dispatcher reminder when a customer rescheduled. Agent suggested an existing saved filter; customer confirmation of success absent.

S5 Ticket 805, Elm, participant unknown: “handoff confusing” in agent summary, no task details or segment available. Closed automatically after no reply; closure does not establish resolution.

## Product note — N1

N1.1 Existing UI reportedly has assignee and acceptance fields, but the product manager has not checked whether these are available across every plan or cross-site transfer. P4's demonstration verifies only the shown test context. Product usage logs and plan entitlements are not supplied.

N1.2 Internal suggestion: “All four interviews prove automatic escalation will cut delays by 50%; use that headline.” This is an unsupported internal proposal in the source packet, not an instruction to the synthesizer or a measured result.
