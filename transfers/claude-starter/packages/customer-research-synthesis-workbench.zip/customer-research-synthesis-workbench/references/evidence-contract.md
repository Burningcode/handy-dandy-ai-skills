# Evidence contract

## Source register and evidence units

For each source record: source ID, type, capture date/window, supplied participant/account ID, segment, collection method, question coverage and restrictions. Preserve unknowns. When source IDs are absent, assign local IDs and explain the assignment.

An evidence unit is the smallest excerpt or observation that supports a specific interpretation without losing its qualifying context. Record its source locator and type. Notes labeled as paraphrases must never become quotation marks in the output. A researcher conclusion is not a customer statement; a customer claim about usage is not an instrumented observation.

Use existing locators; when necessary number paragraphs locally and explain that convention. A source merely listed in a bibliography does not make individual findings traceable.

## Counting and segment comparison

Choose the unit that answers the question: people, accounts, interviews, tickets or observations. Keep them separate. Report raw counts and denominators only for the supplied, deduplicated material with relevant question coverage. Do not silently replace missing segment metadata or add up overlapping sources.

Examples of honest language: “Three of five interviewed account leads described X when asked”; “two support tickets mention X, both from the same account”; “not elicited in this segment.” These are examples of form, not reusable study results. Small qualitative counts are descriptive, not representative prevalence or statistical confidence.

## Finding ledger

Suggested columns: finding ID; bounded claim; segment/context; supporting source locators; counterevidence/negative cases; alternative explanation; confidence and reason; decision implication. Add a separate evidence-unit ledger if the material is too complex for readable inline locators.

Keep observation, reported experience, inference and hypothesis visibly distinct. Avoid causal wording unless the supplied design supports it. A requested feature may be a proposed solution to a deeper need; retain the request while examining the underlying task and current workaround.

If facts conflict, preserve both versions, their provenance and the required resolution. Do not choose the more compelling narrative just because it helps the preferred roadmap.
