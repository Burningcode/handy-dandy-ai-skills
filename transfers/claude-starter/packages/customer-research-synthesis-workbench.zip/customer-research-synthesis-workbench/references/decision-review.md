# From findings to the next research decision

## Bound the recommendation

Explain the target behavior, immediate beneficiary and new friction. Distinguish an observed obstacle from the proposed intervention. Consider whether the intervention shifts work to another role, changes reporting behavior or removes useful checks. Surface the assumption most likely to invalidate the recommendation.

Confidence is a reasoned statement about this finding's evidence, not a universal score: relevant source coverage; direct versus secondhand evidence; leading prompts; independent versus repeated sources; contradictions; and applicability to the decision population. Do not invent a numeric confidence probability.

## A focused follow-up plan

For each necessary follow-up, name the decision-changing uncertainty, target segment, participant/task selection, neutral question or observation, evidence that would support or weaken the hypothesis, and the resulting proceed/change/stop decision. Recruitment counts and thresholds may be proposed but must be labeled as design choices, not power calculations or proven sufficiency.

Avoid “do more interviews” without a distinguishing test. Prefer observing the disputed task or inspecting an authorized artifact when that resolves the ambiguity more directly. Do not imply permission to contact people or access systems. State owners and timing only when supplied.

## Review before delivery

- Can each consequential claim be traced to a supplied locator?
- Are exact quotes distinguishable from paraphrases and inference?
- Were overlapping participants/accounts and duplicate tickets handled?
- Are unanswered questions, negative cases and dissent retained?
- Does the segment comparison separate sampling mix from behavioral difference?
- Are feature demand, willingness to pay, prevalence, causality and measured impact bounded to actual evidence?
- Would plausible contrary evidence change the recommendation? If not, explain why the proposed research is decision-relevant.

The deliverable should reduce the next decision's uncertainty, not manufacture a consensus or finish a PRFAQ, competitive teardown or investment pitch that was not requested.
