# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Distinguish verified reusable components from unverified batch and undo behavior.
- Cover changed eligibility between preview and execution, cross-tenant authorization, partial failure, and reversal.
- Define attempted, per-item succeeded, rejected, and rolled-back states rather than trusting a bulk button click.
- Keep interview evidence directional and time-savings claims unproven.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
