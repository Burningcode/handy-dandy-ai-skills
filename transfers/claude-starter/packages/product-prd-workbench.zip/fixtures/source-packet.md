# HarborDesk: controlled bulk closure

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Source packet
HarborDesk is a B2B support workspace. Support leads want to close groups of already-resolved tickets. The product owner must decide the smallest safe pilot scope. Existing capabilities are a filtered ticket list, single-ticket close with a reason, tenant-scoped authorization, and an audit log. A server-side atomic batch endpoint and an undo workflow have not been verified; treat them as unknown, not existing or absent.

In a synthetic 30-day analysis, 40 accounts produced 2,400 eligible resolved tickets. Support leads manually closed 360 in repetitive groups. An 80-session observational sample recorded a median three minutes per repetitive group; it does not establish time savings from a new feature. Six of 12 research participants requested bulk closure. Two participants described previously closing the wrong selected item. The interview sample is directional, not the customer population.

Only support leads can close tickets. Tickets can be reassigned or reopened between preview and confirmation. Cross-tenant operations are prohibited. The pilot has two engineers for two weeks; operational reversibility is required before expansion.

## Buyer request
Write a pilot PRD. Reuse verified capabilities, expose unknown batch and undo behavior, and specify preview, confirmation, permission rechecks, per-item failure handling, auditability, metrics, and rollback. Preserve unknown owners and dates instead of inventing them. Include one strong alternative and the experiment that distinguishes it.
