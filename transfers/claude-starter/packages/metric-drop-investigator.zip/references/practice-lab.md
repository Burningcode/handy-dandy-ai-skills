# Metric Drop Investigator: practice lab

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

Read `fixtures/source-packet.md` only when the user requests a practice demonstration. Complete its Buyer request using the skill, preserving source labels and uncertainty. For a real task, use the user's evidence and authorized tools instead.

## Repeatable use

1. Capture the user's decision, audience, evidence, and format.
2. Build the smallest output that can change that decision.
3. Apply the skill-specific delivery review and show material unknowns.
4. Return the complete deliverable; do not market hypothetical effects as measured results.

## Transfer exercise

Repeat with one material change: remove a key source, change the eligible population, or add a hard resource or permission constraint. Identify which recommendation changes and which uncertainty remains. A good response adapts to the new evidence rather than repeating the first answer.
