# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Calculate rates from numerators and denominators before explaining the chart.
- Compare within-platform rates and composition; report percentage points separately from relative percentage change.
- Reconcile raw and transformed fields for the exact same cohort before blaming instrumentation.
- Do not blame a release occurring after the inflection or infer the cause of traffic mix without source evidence.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
