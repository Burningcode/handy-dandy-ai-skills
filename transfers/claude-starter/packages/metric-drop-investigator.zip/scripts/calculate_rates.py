"""Calculate supplied aggregate cohort rates. Reads only the explicitly named local CSV."""
import argparse, csv, json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("csv_path", type=Path)
a = p.parse_args()
with a.csv_path.open(newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    required = {"period","platform","eligible","completed","raw_completed","transformed_completed"}
    if not required.issubset(reader.fieldnames or []):
        raise ValueError("Missing required CSV fields")
    rows = list(reader)
if not rows:
    raise ValueError("Empty cohort population")
seen = set()
out = {}
for row in rows:
    key = (row["period"].strip(), row["platform"].strip())
    if not all(key) or key in seen:
        raise ValueError("Period/platform cells must be non-empty and distinct")
    seen.add(key)
    if min(int(row["raw_completed"]), int(row["transformed_completed"])) < 0:
        raise ValueError("Reconciliation counts cannot be negative")
    bucket = out.setdefault(row["period"], {"eligible": 0, "completed": 0, "segments": []})
    eligible, completed = int(row["eligible"]), int(row["completed"])
    if eligible <= 0 or completed < 0 or completed > eligible:
        raise ValueError("Invalid numerator/denominator")
    bucket["eligible"] += eligible
    bucket["completed"] += completed
    bucket["segments"].append({"platform": row["platform"], "eligible": eligible, "completed": completed, "rate": completed/eligible, "raw_matches_transformed": int(row["raw_completed"]) == int(row["transformed_completed"]) == completed})
for bucket in out.values():
    bucket["rate"] = bucket["completed"]/bucket["eligible"]
print(json.dumps(out, indent=2))
