# SignalCart: a conversion-rate investigation

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Source packet
Read `fixtures/metric-windows.csv`. Each row is a disjoint platform-period aggregate. Eligible sessions are deduplicated sessions eligible to check out. Completed means an authoritative completed order within the same seven-day session cohort. `raw_completed` and `transformed_completed` are count reconciliation fields for the same population. Gross orders are used; refunds are outside this exercise.

Before window: 2026-09-01 through 2026-09-07. After window: 2026-09-08 through 2026-09-14. A UI fix was deployed on 2026-09-15, after both windows. No traffic-campaign log, randomized experiment, or user replay has been supplied. The dashboard reports a decline; the operator wants to know where to investigate first.

## Buyer request
Explain the overall and within-platform movement, reconcile raw/transformed counts, separate mix from conversion changes, and write a hypothesis board with confidence and one discriminating next test. Use only the supplied synthetic data. If running the optional helper, give the CSV path explicitly; it uses only the supplied local file and prints calculations.

## Additional practice
`fixtures/within-segment-decline.csv` is a second synthetic cohort with the same metric definitions and comparison windows. Investigate it independently rather than reusing the first diagnosis.
