# Delivery review

Evaluate the output against the actual user request, not a preferred recommendation.

- Make the customer job recognizable without a feature inventory.
- Label future quotes illustrative and avoid invented commercial proof.
- Compare status clarity with improving current email before choosing investment.
- Preserve spending authority and unresolved escalation/delegation capability.

## Release decision

A usable deliverable preserves supplied facts, identifies the decision, makes unsupported inputs visible, and contains a concrete next action. If a critical source, authorization, or required output tool is unavailable, name the limitation and provide the best verifiable bounded output. Do not label an unrun validation as passed.
