# LumenPlan: procurement approval clarity

All companies, observations, dates, customer quotes, and numerical values in this fixture are fictional simulation data. They do not describe a real company or a measured customer result.

## Source packet
LumenPlan serves operations teams at companies with 50-200 employees. Eight buyer interviews identified repeated chasing for purchase approval status; five described it as weekly work. Twelve requester interviews identified six cases in which the requester did not know which approver was responsible. These are small qualitative samples.

The current product has request submission, approver assignment, an approved/rejected state, and email notifications. Delegation, approval escalation, and Slack integration have not been verified. Procurement policies remain company-owned. A feature must not approve spending automatically or override the configured approver.

The decision is whether to fund a four-week status-clarity pilot or prioritize improving existing email messages. No observed retention, labor-saving, pricing, or revenue lift is available. The initial audience is requesters and approvers at existing customers, not every employee in every company.

## Buyer request
Create a future press release and internal FAQ for an approval-status experience. Treat future quotes as illustrative. Explain the customer behavior, meaningful differentiation, credible email-only alternative, policy boundary, unknown economics, smallest pilot, and continue/modify/stop gate. Do not invent launch commitments or actual customer outcomes.
