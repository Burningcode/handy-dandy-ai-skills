# Readiness and evidence

Use this to review a supplied backlog without converting documentation quality into a false verdict about product value.

## What the assessment means

Define the next decision: grooming, discovery, implementation planning or a release gate. A ticket can be suitable for grooming while still lacking an engineering estimate or policy decision. Conversely, a detailed ticket may conflict with the supplied product intent. Do not use Ready without saying ready for what.

For a grooming review, a useful proposed threshold is: an understandable actor/problem, a bounded intended behavior, enough source context to discuss a slice, and a clear unresolved decision. Implementation readiness additionally needs an agreed testable contract and material dependencies/risks resolved. These are proposed review standards when the team supplies none, not universal process rules.

Use plain dispositions such as:

| Review disposition | What supports it | What it does not mean |
| --- | --- | --- |
| Groom now | Enough evidence to discuss a meaningful decision/slice | Approved for delivery or proven valuable |
| Repair proposal | A concrete text/scope improvement can be drafted from sources | New acceptance criteria are already agreed |
| Evidence needed | Missing observation, requirement, context or decision changes the assessment | The problem is invalid, low value or permanently not ready |
| Source-confirmed constraint | An explicit source policy/constraint prevents the proposed path | A stale Blocked label or unverified tracker link is proof |
| Outside current intent | Supplied scope makes it a separate decision | Delete, reject or reprioritize it without the owner |

Choose one primary disposition per item if a table needs it, adding qualifiers where appropriate. Preserve the team's reported status separately. If two interpretations remain plausible, state them and identify the deciding evidence.

## Evidence contract

For each material judgment link to ticket ID/field, context section, supplied attachment or authorized read. Classify:

- **Source statement:** the provided policy, baseline or planning limit says this.
- **Reported observation:** a ticket/reporter describes behavior; reproduction or trace may be absent.
- **Inference:** the review derives a likely relationship or explanation.
- **Proposal:** new text, target, scope, sequencing or ownership for review.
- **Unknown:** absent evidence that cannot safely be supplied by the reviewer.

Confidence should have a concrete reason, not a percentage. A direct export link is high confidence as a recorded link but may remain low confidence as a technical prerequisite. A title match is weak evidence of duplication. The supplied baseline is authoritative within the review packet; do not call it independently verified production state unless a live source proves that.

## Assessment row

Include ID, reported type/status/priority, relation to intended outcome, primary review disposition, strongest evidence, exact gap/decision and proposed accountable role. Avoid mechanically scoring each missing field. Absence of a named owner can be an assignment decision rather than a reason to discard an otherwise clear item.

Count only the supplied in-scope rows after checking unique IDs. Distinguish a full small export from a sample of a larger backlog. If IDs repeat with different text, keep the conflict visible rather than dropping a row. Do not claim that an export represents the company's complete backlog unless the source says so.

For prioritization, use ordinal discussion order with a brief rationale grounded in outcome, risk, explicit time constraint and enabling decisions. If the user requests a quantitative method, show missing inputs and ranges/assumptions; do not fabricate reach, effort or impact to produce a precise rank.
