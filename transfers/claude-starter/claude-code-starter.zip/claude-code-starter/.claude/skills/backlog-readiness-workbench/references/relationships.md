# Duplicates and dependencies

Use this when ticket relationships affect the next discussion or repair. A map is an evidence-backed proposal, not authority to rewrite tracker links.

## Duplicate candidates

Compare actor, triggering situation, current versus intended behavior, object/state, platform and acceptance scope. Similar wording, shared component or the same reporter is not enough. A reported duplicate link is a claim to inspect, not a resolved merge.

For each pair/group show:

| Items | Relationship hypothesis | Evidence for / against | Next verification | Proposed handling |
| --- | --- | --- | --- | --- |

Useful outcomes include duplicate candidate, shared underlying cause, overlapping scope, distinct surfaces or insufficient evidence. Explain the consequence of a mistaken merge: a bug surface or actor requirement could disappear. Preserve each ID and every distinct acceptance/reproduction detail in any proposed merged draft. Do not mark a ticket duplicate, closed or deleted without authorized action and resulting-state evidence.

If separate work is warranted, suggest a shared investigation or source reference rather than manufacturing a dependency. If an item mixes distinct outcomes, propose a split with its rationale; new IDs and owner assignments remain proposals.

## Dependency map

State direction explicitly: `A -> B` means A is recorded or proposed as waiting for B. Include edge source, relationship class and verification question. Do not silently reverse a link to make the graph convenient.

Keep these distinct:

- An exported `depends_on` value proves the source recorded an edge.
- A description may report a prerequisite without an actual tracker link.
- The reviewer may infer an enabling order from a shared API or decision.
- An explicit policy or confirmed contract can establish a real prerequisite within the supplied record.

For missing endpoint IDs, record outside-export or unknown, not nonexistent. Ask for the relevant source or owner confirmation. For cycles, report the exact recorded edges, then test whether they express a true technical sequence, a shared design decision or stale/incorrect links. Suggest a decision, interface slice or paired refinement that could break the uncertainty; do not assert an architectural fix from ticket names alone.

An item marked Blocked can still enter grooming to resolve its blocking decision. A recorded dependency can be removed only as an authorized reviewed tracker change; a map alone changes nothing.
