# Ticket repairs and session planning

Return usable ticket text and decision work, not a list of headings the buyer must complete alone.

## Exact repair drafts

For each requested item preserve its ID and identify fields being replaced, facts retained and proposals added. Keep reported priority/status/type visible; changing the proposed type or scope is an explicit review decision, not a silent edit.

A bug repair should include a concrete symptom/title, reported environment, reproduced versus reported status, supplied steps, expected behavior from a cited contract, actual reported behavior, impact evidence and verifiable acceptance tests. If steps/environment/trace are absent, say precisely what is missing. You may propose a test setup, but do not call it the original reproduction or a successful diagnosis.

A story/change repair should name actor, context, desired behavior, outcome, in/out scope and acceptance cases. Use known objects and policy boundaries. A spike should name the decision it resolves, evidence required, bounded work and the next choice; it is not an unlimited research ticket.

Acceptance criteria must distinguish:

- what the supplied contract already requires;
- a proposed behavior/test for the intended change; and
- an unresolved value/decision that prevents final agreement.

When the source lacks a target, propose a labeled candidate threshold with a reason or an explicit choice to resolve it. Never turn a desired latency, volume, effort or release date into a measured baseline or an approved promise. If a criterion cannot become testable without a missing policy, retain a useful draft and mark that decision open. Do not label every repaired ticket implementation-ready.

Add a compact change ledger: original field problem, replacement field, source IDs and approval/evidence needed. Avoid changing unrelated fields or adding an unsolicited project-wide format.

## Grooming agenda

Start with the named outcome and decision horizon, then order the highest-value unresolved decisions. Cover material safety/risk first when supplied evidence warrants it, relationship/contract decisions that unblock work, the most coherent release slice and specific evidence assignments. Do not equate a severe report with confirmed incident frequency or invent urgency merely from a High priority label.

Each agenda item needs time, ticket/theme, decision requested, participant/owner role, evidence and desired output. Sum the time against the supplied limit. Move optional detail to pre-read rather than overfilling the session. A proposed role is acceptable when no named owner exists; do not imply attendance, acceptance or a new commitment.

Close with a decision log: what can proceed, what remains a proposal, what source is needed, who should resolve it and the next review point. No message or calendar event is sent by writing this agenda. If an external tracker update is separately authorized, verify current fields and save/read back only that explicit scope with an available documented tool. Otherwise return the exact local diff/handoff and retain the reported source state.
