---
name: backlog-readiness-workbench
description: Review supplied tickets against product intent, map possible duplicates and dependencies, draft exact ticket repairs, and prepare a focused grooming agenda. Use for backlog readiness and refinement preparation, not autonomous reprioritization, ticket deletion, or tracker writes without scoped authorization.
---

# Backlog Readiness Workbench

Help a team decide what it can discuss or refine next, why another item needs evidence, and which exact words or decisions would make progress. A well-written ticket is not proof that its problem, dependency or delivery estimate is verified.

## Set the review boundary

Use the supplied export, product intent and team readiness rules. Record snapshot date, included IDs, intended user outcome, planning constraints and the requested output. Review every in-scope item, preserving IDs and reported type/status/priority. For a single-ticket request, inspect only that item and the context needed to repair it; do not expand into a portfolio audit.

An export is evidence of what was recorded, not a live-state check or reproduction. Separate supplied facts, reported observations, inferred relationships, proposed repairs and missing evidence. Read [readiness and evidence](references/readiness-and-evidence.md) for the assessment contract.

## Assess before rewriting

Check whether the item explains the actor/problem, intended behavior, scope, observable acceptance, material constraints and the next accountable decision. Use the team's threshold when supplied; otherwise state a small proposed grooming threshold. Do not require full implementation certainty to discuss a useful slice.

Keep review disposition separate from reported workflow status. Missing facts mean evidence is incomplete, not that the idea is invalid or low priority. A recorded Blocked label alone does not establish the current dependency. A draft repair can be useful while a policy or scope decision remains unresolved. Do not invent an estimate, owner commitment, metric baseline or release promise to complete a row.

## Map relationships without collapsing work

Read [duplicates and dependencies](references/relationships.md). Identify plausible overlap and distinguishing evidence. Preserve every ticket; suggest merge/split/link decisions for review rather than deleting or silently treating two similar titles as one problem.

For dependency edges distinguish an exported link, a reported prerequisite, an inferred prerequisite and a source-confirmed constraint. Expose missing IDs and cycles in the supplied graph. A cycle of tracker links is not proof of an architectural deadlock. Name the question or evidence that would establish the actual order.

## Draft exact repairs and a session plan

Read [ticket repairs and session planning](references/repair-and-session.md). Return actual replacement titles/bodies/acceptance criteria for the requested items, with a short field-change ledger. Preserve source-supported behavior and reproduction details; mark new boundaries, targets and acceptance tests as proposals until accepted. Use bug structure for reported failures and outcome structure for requested change. Do not fill absent bug steps with imagined clicks or claim an unrun reproduction.

Order the grooming discussion by supplied outcome, material risk, explicit timing and decisions that unblock other work. Show the reason and source; do not turn missing reach/effort into a made-up weighted score. Agenda ownership can be a proposed role when no person is assigned. A meeting slot is not a delivery commitment.

A full review should include:

- one row per in-scope ticket, readiness disposition and exact evidence/question;
- a duplicate-candidate and dependency map with confidence and verification needs;
- the requested complete repair drafts and source-versus-proposal changes;
- a time-bounded agenda of decisions, participants and desired outputs; and
- unresolved inputs, responsible roles and what can advance independently.

Use the user's requested format; a concise Markdown review is the default. Keep supporting detail only when it changes a decision.

## Protect the boundary and verify delivery

Review proposals do not authorize external edits, links, merges, deletes, comments or messages. If the user separately authorizes exact tracker changes and a documented tool is available, fresh-read affected records, apply only that scope and read back the result. A changed source or unsupported tool leaves that edit as a handoff; it does not erase independent completed work.

Before delivery, reconcile item coverage and relationship endpoints, inspect the actual repair text against sources, and distinguish facts from draft decisions. Check agenda duration when a limit is supplied. Report local drafts, authorized changes and verified readbacks separately. Do not label missing evidence resolved, a candidate duplicate merged or a drafted ticket saved.

## Original fictional first-use exercise

Follow [the buyer request](fixtures/buyer-request.md) using [the product context](fixtures/context.md) and `fixtures/tickets.csv`. All data are invented; no real account, connector or private template is needed. The package supplies raw work to review, not an answer key or model result.
