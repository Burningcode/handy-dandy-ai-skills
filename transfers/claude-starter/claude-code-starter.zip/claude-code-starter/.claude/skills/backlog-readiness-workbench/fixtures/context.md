# OrchardRelay product-intent packet

All organizations, ticket IDs, observations, roles, dates and numbers in this packet are fictional simulation material. No real company system or private customer data is present.

Snapshot: October 13, 2026. The accompanying CSV contains all 12 items selected for this review, not the company's entire backlog. Recorded labels and links can be stale; no live tracker or production environment is available.

## C1 - Intended outcome

OrchardRelay is a request-approval workspace. The next pilot should help an authorized requester identify the responsible approver and understand the authoritative request status without asking support. No support-contact baseline or intervention effect has been measured in this exercise. Discussion should concentrate on this outcome rather than a general notification or reporting roadmap.

## C2 - Supplied product baseline and policy

The supplied baseline has a request record, assigned approver, states Draft/Pending/Approved/Rejected, a request details page, approve/reject actions, field validation and an audit trail. The current CSV export includes request ID, state and approver ID. Whether it supports date filters or a readable approver name is not established.

Only the currently assigned approver may approve a Pending request. A requester may view their own request and its assigned approver. A successful transition must leave the audit history intact and identify the acting user and resulting state. These are the supplied product rules; the packet does not prove current enforcement in every reported scenario.

## C3 - Pilot boundaries

The pilot should preserve access control and final decisions. Automatically approving requests, changing an approved/rejected request back to Pending, deleting audit records, mobile push, SMS and a new messaging integration are outside this pilot. Human email reminders might be a later product choice; no channel policy or delivery schedule is supplied.

## C4 - Unsettled decisions

No freshness/refresh interval, latency success target or API cache contract has been agreed. Existing analytics-event coverage and experiment assignment/reporting have not been verified. Reopening or refocusing a page versus continuous refresh are viable discussion options, not approved scope. Do not assume an API, instrumented event or feature is absent because it is not described here.

## C5 - Capacity and timing

Two engineers have ten working days of capacity planned for the pilot after scope agreement; ticket estimates are missing. A 45-minute grooming session is planned for October 20. The team aims to agree a candidate scope by October 22 and target a pilot on October 29; these planning dates are not implementation guarantees. Product manager, engineering lead, designer and support lead are the intended review roles. Named owners/attendance are not supplied.

## C6 - Source quality

The CSV is a raw worklist. Ticket descriptions are reporter statements unless the text supplies stronger evidence. Mentioned screenshots/traces are not attached. `depends_on` and `possible_duplicate_of` are export fields; they do not independently establish technical prerequisites or true duplication. OR-999 is not in this export, and its contents are unknown. A Blocked/Ready label is not the reviewer verdict.

## C7 - Requested boundary

Use only this packet and the raw CSV. Prepare local review and repair proposals; no ticket creation/update/link/merge/delete, messages, research, calendars or account actions are authorized.
