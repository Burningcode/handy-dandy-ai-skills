# Fictional buyer request

Use `$backlog-readiness-workbench` to prepare our 45-minute OrchardRelay grooming session from `context.md` and `tickets.csv`. All inputs are fictional. Use only these files; no connected service or external action is authorized.

Return the actual review, not a plan to do it:

1. A readiness assessment for all 12 supplied IDs, preserving reported type/status/priority and citing the exact source of each judgment. Distinguish a missing fact from a source-confirmed constraint and from a useful item we can discuss now.
2. A duplicate-candidate and dependency map. Explain what is recorded, what you infer, what could be distinct and which missing source or decision would settle it. Do not delete or merge anything.
3. Complete proposed replacement tickets for OR-104, OR-107, OR-109 and OR-112: titles, bodies, acceptance criteria and a short field-change ledger. Preserve reported facts, identify proposed scope/tests and leave unresolved evidence or policy visible. Do not claim that a draft has become agreed implementation scope.
4. A grooming agenda totaling no more than 45 minutes, with decisions, source-linked rationale, participant/owner roles and desired outputs. Explain the discussion order without invented effort, reach or numeric priority scores.
5. A short handoff of open evidence/decisions and what can advance independently. Report local proposals only; nothing is updated in a tracker, sent, scheduled or externally verified.

The packet is sufficient for a bounded review. Do not demand a live account or fill missing details from imagination. No model answer or evaluator key is supplied.
